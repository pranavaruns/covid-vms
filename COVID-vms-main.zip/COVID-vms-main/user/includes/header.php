<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.php">Covid Vaccination</a></h1>
</div>
<!--close-Header-part-->

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li class="" ><a title="" href="profile.php"><i class="icon icon-user"></i> <span class="text">Profile</span></a></li>
    
    <li class=""><a title="" href="change-password.php"><i class="icon icon-cog"></i> <span class="text">Settings</span></a></li>
    <li class=""><a title="" href="logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--close-top-Header-menu-->

<div id="sidebar"><a href="dashboard.php" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a><ul>
    <li class="active"><a href="dashboard.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    
    <li><a href="vaccination-form.php"><i class="icon icon-fullscreen"></i> <span>Vaccination Booking Form</span></a></li>
    <li><a href="vaccination-history.php"><i class="icon icon-th"></i> <span>Vaccination History</span></a></li>
    
  </ul>
</div>