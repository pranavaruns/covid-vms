<div class="row-fluid">
  <div id="footer" class="span12"> Covid Vaccination Management System</div>
</div>